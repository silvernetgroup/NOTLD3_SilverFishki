﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SilverFiszki
{
    public class Main
    {
        public bool isPolishToEnglish = true;
    }
}
